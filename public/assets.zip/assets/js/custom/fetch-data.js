function fetchItemsData(options, callback) {
    // Assign default values if options is not provided
    if (!options) {
        options = {};
    }

    // Set default values for task and mode if not provided
    const task = options.task || 'GET';
    const mode = options.mode || 'LIST';
    axios.post('/api/v2/data/items', {
        task: task, 
        mode: mode,
    }, { // Pass headers as the second argument to axios.post
        headers: {
            'Authorization': 'Bearer ' + window.AuthToken,
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    })
    .then(function (response) {
        var itemsData = response.data;
        // console.log(itemsData);
        if (typeof callback === "function") {
            callback(itemsData);
        } 
        // Process the itemsData here, e.g., display it in a table
    })
    .catch(function (error) {
        if (error.response && error.response.status === 401) {
            console.error('Unauthorized access - please log in again.');
            window.location.href = '/login'; 
        } else {
            console.error('Error fetching items data:', error);
        }
    });
}

function fetchFarmsData(options, callback) {
    // Assign default values if options is not provided
    options = options || {};

    // Set default values for task and mode if not provided
    const task = options.task || 'GET';
    const mode = options.mode || 'LIST';
    const submodul = options.submodul || '';
    
    // Construct the URL with submodul if it exists
    const url = submodul ? `/api/v2/data/farms/${submodul}` : '/api/v2/data/farms';

    // Prepare the data object
    const data = { task, mode };
    
    // Include farm_id only if it exists
    if (options.farm_id) {
        data.farm_id = options.farm_id;
    }

    axios.post(url, data, { // Pass headers as the second argument to axios.post
        headers: {
            'Authorization': 'Bearer ' + window.AuthToken,
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    })
    .then(function (response) {
        var itemsData = response.data;
        if (typeof callback === "function") {
            callback(itemsData);
        } 
    })
    .catch(function (error) {
        if (error.response && error.response.status === 401) {
            console.error('Unauthorized access - please log in again.');
            window.location.href = '/login'; 
        } else {
            console.error('Error fetching items data:', error);
        }
    });
}

function fetchFarmDetailsData(callback) {
    const task = 'GET_DETAILS';
    const mode = 'LIST';
    axios.post('/api/v2/data/farms', {
        task: task, 
        mode: mode,
    }, { // Pass headers as the second argument to axios.post
        headers: {
            'Authorization': 'Bearer ' + window.AuthToken,
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    })
    .then(function (response) {
        var itemsData = response.data;
        // console.log(itemsData);
        if (typeof callback === "function") {
            callback(itemsData);
        } 
        // Process the itemsData here, e.g., display it in a table
    })
    .catch(function (error) {
        if (error.response && error.response.status === 401) {
            console.error('Unauthorized access - please log in again.');
            window.location.href = '/login'; 
        } else {
            console.error('Error fetching items data:', error);
        }
    });
}